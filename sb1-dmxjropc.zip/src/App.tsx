import React, { useState, useEffect } from 'react';
import { Stock, PortfolioMetrics } from './types';
import { Dashboard } from './components/Dashboard';
import { StockList } from './components/StockList';
import { StockForm } from './components/StockForm';
import { mockStocks } from './mockData';
import { LayoutGrid, Plus } from 'lucide-react';

function App() {
  const [stocks, setStocks] = useState<Stock[]>(mockStocks);
  const [editingStock, setEditingStock] = useState<Stock | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [metrics, setMetrics] = useState<PortfolioMetrics>({
    totalValue: 0,
    totalGainLoss: 0,
    topPerformer: null,
    worstPerformer: null,
  });

  useEffect(() => {
    calculateMetrics();
  }, [stocks]);

  const calculateMetrics = () => {
    const totalValue = stocks.reduce(
      (sum, stock) => sum + stock.currentPrice * stock.quantity,
      0
    );

    const totalGainLoss = stocks.reduce(
      (sum, stock) =>
        sum + (stock.currentPrice - stock.buyPrice) * stock.quantity,
      0
    );

    const sortedByPerformance = [...stocks].sort(
      (a, b) =>
        (b.currentPrice - b.buyPrice) / b.buyPrice -
        (a.currentPrice - a.buyPrice) / a.buyPrice
    );

    setMetrics({
      totalValue,
      totalGainLoss,
      topPerformer: sortedByPerformance[0] || null,
      worstPerformer: sortedByPerformance[sortedByPerformance.length - 1] || null,
    });
  };

  const handleAddStock = (stockData: Partial<Stock>) => {
    const newStock: Stock = {
      id: Date.now().toString(),
      symbol: stockData.symbol!,
      name: stockData.name!,
      quantity: stockData.quantity!,
      buyPrice: stockData.buyPrice!,
      currentPrice: stockData.buyPrice!, // In a real app, this would come from an API
    };
    setStocks([...stocks, newStock]);
    setShowForm(false);
  };

  const handleUpdateStock = (stockData: Partial<Stock>) => {
    if (!editingStock) return;
    
    const updatedStocks = stocks.map((stock) =>
      stock.id === editingStock.id
        ? {
            ...stock,
            ...stockData,
            currentPrice: stock.currentPrice, // Preserve current price
          }
        : stock
    );
    setStocks(updatedStocks);
    setEditingStock(null);
    setShowForm(false);
  };

  const handleDeleteStock = (id: string) => {
    setStocks(stocks.filter((stock) => stock.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center">
            <LayoutGrid className="h-8 w-8 text-indigo-600 mr-2" />
            <h1 className="text-2xl font-bold text-gray-900">Portfolio Tracker</h1>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Stock
          </button>
        </div>

        <Dashboard stocks={stocks} metrics={metrics} />

        {showForm && (
          <div className="mb-8">
            <StockForm
              stock={editingStock || undefined}
              onSubmit={editingStock ? handleUpdateStock : handleAddStock}
              onCancel={() => {
                setShowForm(false);
                setEditingStock(null);
              }}
            />
          </div>
        )}

        <StockList
          stocks={stocks}
          onEdit={(stock) => {
            setEditingStock(stock);
            setShowForm(true);
          }}
          onDelete={handleDeleteStock}
        />
      </div>
    </div>
  );
}

export default App;