# Portfolio Tracker

A responsive web application for tracking stock portfolios built with React, TypeScript, and Tailwind CSS.

## Live Demo

The application is deployed and can be accessed at: [Portfolio Tracker](https://portfolio-tracker-demo.netlify.app)

## Features

- Add, edit, and delete stock holdings
- Track total portfolio value
- View portfolio metrics in a dashboard
- Responsive design that works on desktop and mobile
- Real-time updates of stock values
- Beautiful UI with Tailwind CSS

## Technologies Used

- React 18
- TypeScript
- Tailwind CSS
- Vite
- Lucide React (for icons)

## Local Development Setup

1. Clone the repository:
```bash
git clone [your-repository-url]
cd portfolio-tracker
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and visit `http://localhost:5173`

## Build for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## Project Structure

```
src/
├── components/         # React components
│   ├── Dashboard.tsx  # Portfolio metrics dashboard
│   ├── StockForm.tsx  # Form for adding/editing stocks
│   └── StockList.tsx  # Table of stock holdings
├── types.ts           # TypeScript interfaces
├── mockData.ts        # Sample stock data
└── App.tsx           # Main application component
```

## Assumptions and Limitations

1. Stock Data:
   - Currently using mock data for demonstration
   - In a production environment, would integrate with a real stock API
   - Stock prices are static and don't update in real-time

2. Authentication:
   - No user authentication implemented
   - Single portfolio view for demonstration

3. Data Persistence:
   - Data is stored in memory and resets on page refresh
   - In production, would persist data in a backend database

## Future Improvements

1. Integration with real stock market API for live prices
2. User authentication and multiple portfolios
3. Data persistence with a backend server
4. Additional portfolio analytics and charts
5. Stock search functionality with autocomplete
6. Mobile app version

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.